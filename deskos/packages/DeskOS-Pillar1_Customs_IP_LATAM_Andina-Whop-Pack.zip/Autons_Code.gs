/**
 * DeskOS (DeskoS) Autonomous Operating System — Attached Auton Module
 * Target Firm: Andina Customs & IP Counsel (Bogotá, CO)
 * Pillar: Pillar 1 — Boutique Customs Clearing/Freight Forwarders & Boutique IP/Trademark Law Firms
 * Unit ID: deskos-co-andina-customs-ip-counse-7351bf75
 *
 * Vocabulary & Architecture:
 * - WorkCells (wC01..wC06): Operational stations inside this DeskOS unit.
 * - Autons: Autonomous engines executing on the user's own Google + BYOK LLM quotas.
 */

var DESKOS_CONFIG = {
  UNIT_ID: "deskos-co-andina-customs-ip-counse-7351bf75",
  UNIT_TOKEN: "dsk_tok_7f906898d267fcc5c0019ac8f7fd",
  MASTER_OS_URL: "https://stpi-leads.stpi-cloud.workers.dev",
  FIRM_NAME: "Andina Customs & IP Counsel",
  PILLAR_ID: "customs_ip"
};

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("⚡ DeskOS Command")
    .addItem("1. Flip Dead-Sheet Switch ON (Activate Daily Stream)", "RadarAuton_enableLiveStream")
    .addItem("2. Flip Dead-Sheet Switch OFF (Pause Daily Stream)", "RadarAuton_disableLiveStream")
    .addSeparator()
    .addItem("3. Run KeyGateAuton (Process Day 3+ Signals via wC05 BYOK Key)", "KeyGateAuton_processPending")
    .addItem("4. Run DispatchAuton (Send Approved wC02 Advisories)", "DispatchAuton_sendApproved")
    .addItem("5. Run UpgradeAuton (Verify Whop License Key in wC06-B4)", "UpgradeAuton_verifyLicense")
    .addToUi();
}

function RadarAuton_enableLiveStream() {
  return RadarAuton_setSwitch(true);
}

function RadarAuton_disableLiveStream() {
  return RadarAuton_setSwitch(false);
}

function RadarAuton_setSwitch(active) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var wc01 = ss.getSheetByName("wC01_Live_Radar");
  if (wc01) {
    wc01.getRange("B2").setValue(active ? "ON" : "OFF");
  }
  var res = UrlFetchApp.fetch(DESKOS_CONFIG.MASTER_OS_URL + "/sheet-switch", {
    method: "post",
    contentType: "application/json",
    headers: { "X-DeskOS-Unit-Token": DESKOS_CONFIG.UNIT_TOKEN },
    payload: JSON.stringify({
      sheet_id: DESKOS_CONFIG.UNIT_ID,
      active: active,
      firm_name: DESKOS_CONFIG.FIRM_NAME
    }),
    muteHttpExceptions: true
  });
  return JSON.parse(res.getContentText());
}

function KeyGateAuton_processPending() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var wc05 = ss.getSheetByName("wC05_BYOK_Key_Bay");
  var provider = wc05 ? String(wc05.getRange("B4").getValue() || "").trim() : "";
  var apiKey = wc05 ? String(wc05.getRange("B5").getValue() || "").trim() : "";
  if (!apiKey) {
    SpreadsheetApp.getUi().alert(
      "BYOK Default Gate: WorkCell 01 has received raw Day 3+ intelligence, " +
      "but WorkCell 05 (cell B5) has no API key yet. Paste your free Gemini or Groq key in wC05-B5 to process."
    );
    return { ok: false, reason: "BYOK_KEY_MISSING" };
  }
  return { ok: true, provider: provider || "gemini", quota_owner: "client_byok" };
}

function DispatchAuton_sendApproved() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var wc02 = ss.getSheetByName("wC02_Approve_Dispatch");
  if (!wc02) return { ok: false, sent: 0 };
  var rows = wc02.getDataRange().getValues();
  var sentCount = 0;
  for (var i = 3; i < rows.length; i++) {
    if (String(rows[i][2]) === "APPROVED") {
      var toAddr = String(rows[i][3] || "").trim();
      var subj = String(rows[i][4] || "").trim();
      var body = String(rows[i][5] || "").trim();
      if (toAddr && subj && body) {
        MailApp.sendEmail(toAddr, subj, body);
        wc02.getRange(i + 1, 3).setValue("DISPATCHED");
        sentCount++;
      }
    }
  }
  return { ok: true, sent: sentCount };
}

function UpgradeAuton_verifyLicense() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var wc06 = ss.getSheetByName("wC06_Command_Upgrade_Gate");
  var key = wc06 ? String(wc06.getRange("B4").getValue() || "").trim() : "";
  if (key.indexOf("STP1.") === 0 && key.split(".").length === 4) {
    wc06.getRange("B5").setValue("SOVEREIGN_PRO_UNLOCKED");
    return { ok: true, status: "SOVEREIGN_PRO_UNLOCKED" };
  }
  return { ok: false, status: "FREE_BYOK_MODE" };
}
